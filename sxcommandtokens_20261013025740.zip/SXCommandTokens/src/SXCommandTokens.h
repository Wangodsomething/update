#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

// Text protocol vocabulary. These are not numeric wire opcodes.
namespace sx { namespace commands {
constexpr size_t MAX_COMMAND = 255;
constexpr size_t MAX_TOKENS = 12;
constexpr unsigned VERSION = 1;

namespace universal {
constexpr char kCheck[] = "check";
constexpr char kConfirm[] = "confirm";
constexpr char kFormat[] = "format";
constexpr char kLittlefs[] = "littlefs";
constexpr char kConf[] = "conf";
constexpr char kConfig[] = "config";
constexpr char kData[] = "data";
constexpr char kEspnow[] = "espnow";
constexpr char kFalseValue[] = "false";
constexpr char kGet[] = "get";
constexpr char kHelp[] = "help";
constexpr char kId[] = "id";
constexpr char kImei[] = "imei";
constexpr char kBle[] = "ble";
constexpr char kMac[] = "mac";
constexpr char kMqtt[] = "mqtt";
constexpr char kOff[] = "off";
constexpr char kOn[] = "on";
constexpr char kPrint[] = "print";
constexpr char kQueue[] = "queue";
constexpr char kRestart[] = "restart";
constexpr char kScan[] = "scan";
constexpr char kSet[] = "set";
constexpr char kTime[] = "time";
constexpr char kTrueValue[] = "true";
constexpr char kUpdate[] = "update";
constexpr char kVersion[] = "version";
constexpr char kWifi[] = "wifi";
}

namespace icebox {
constexpr char kStationary[] = "stationary";
constexpr char kMobile[] = "mobile";
constexpr char kExit[] = "exit";
constexpr char kHumi[] = "humi";
constexpr char kMode[] = "mode";
constexpr char kPower[] = "power";
constexpr char kQuit[] = "quit";
constexpr char kRadio[] = "radio";
constexpr char kSaving[] = "saving";
constexpr char kTemp[] = "temp";
constexpr char kTimezone[] = "timezone";
}

namespace h1 {
constexpr char kActive[] = "active";
constexpr char kAdd[] = "add";
constexpr char kAlert[] = "alert";
constexpr char kAll[] = "all";
constexpr char kApn[] = "apn";
constexpr char kBreaker[] = "breaker";
constexpr char kBuzzer[] = "buzzer";
constexpr char kClear[] = "clear";
constexpr char kClose[] = "close";
constexpr char kCorrupt[] = "corrupt";
constexpr char kCrc[] = "crc";
constexpr char kDebug[] = "debug";
constexpr char kDin[] = "din";
constexpr char kDisplay[] = "display";
constexpr char kError[] = "error";
constexpr char kHigh[] = "high";
constexpr char kKey[] = "key";
constexpr char kLevel[] = "level";
constexpr char kList[] = "list";
constexpr char kLog[] = "log";
constexpr char kLow[] = "low";
constexpr char kModbus[] = "modbus";
constexpr char kModem[] = "modem";
constexpr char kMongolia[] = "mongolia";
constexpr char kNokia[] = "nokia";
constexpr char kOpen[] = "open";
constexpr char kPassive[] = "passive";
constexpr char kPeer[] = "peer";
constexpr char kPeriodic[] = "periodic";
constexpr char kPhone[] = "phone";
constexpr char kReason[] = "reason";
constexpr char kRecord1[] = "record1";
constexpr char kRecord2[] = "record2";
constexpr char kRemove[] = "remove";
constexpr char kReset[] = "reset";
constexpr char kRingtone[] = "ringtone";
constexpr char kSensor[] = "sensor";
constexpr char kSim[] = "sim";
constexpr char kStatus[] = "status";
constexpr char kTcp[] = "tcp";
constexpr char kTimeout[] = "timeout";
constexpr char kVolume[] = "volume";
constexpr char kWrite[] = "write";
}

struct Token {
    char *text = nullptr; // View into caller-owned mutable input; never allocated.
    bool quoted = false;
};
enum class ParseError : uint8_t {
    None, NullInput, TooLong, InvalidCharacter, TooManyTokens, InvalidQuote
};
inline bool whitespace(char c) {
    return c == ' ' || c == '\t' || c == '\r' || c == '\n';
}
inline char asciiLower(char c) { return c >= 'A' && c <= 'Z' ? char(c + ('a' - 'A')) : c; }
inline bool keywordEqual(const char *text, const char *keyword) {
    if (!text || !keyword) return false;
    while (*text && *keyword) {
        if (asciiLower(*text++) != asciiLower(*keyword++)) return false;
    }
    return *text == *keyword;
}
// Recognize the same identity grammar for char* and Arduino String tokens.
inline const char *tokenText(const char *text) { return text; }
inline const char *tokenText(char *text) { return text; }
template<class Text> inline const char *tokenText(const Text &text) { return text.c_str(); }
enum class IdentityQuery : uint8_t { None, Imei, WifiMac, BleMac, Invalid };
template<class CommandToken>
IdentityQuery identityQuery(const CommandToken *tokens, size_t count) {
    if (!tokens || count < 2 || tokens[0].quoted ||
        !keywordEqual(tokenText(tokens[0].text), universal::kGet)) return IdentityQuery::None;
    const char *target = tokenText(tokens[1].text);
    const bool imei = keywordEqual(target, universal::kImei);
    const bool wifi = keywordEqual(target, universal::kWifi);
    const bool ble = keywordEqual(target, universal::kBle);
    if (!imei && !ble && !(wifi && count > 2)) return IdentityQuery::None;
    if (tokens[1].quoted) return IdentityQuery::Invalid;
    if (imei) return count == 2 ? IdentityQuery::Imei : IdentityQuery::Invalid;
    if (count != 3 || tokens[2].quoted ||
        !keywordEqual(tokenText(tokens[2].text), universal::kMac)) return IdentityQuery::Invalid;
    return wifi ? IdentityQuery::WifiMac : IdentityQuery::BleMac;
}
// Shared maintenance grammar; file printing already uses universal::kPrint.
enum class LittlefsCommand : uint8_t { None, Check, Format, Invalid };
template<class CommandToken>
LittlefsCommand littlefsCommand(const CommandToken *tokens, size_t count) {
    if (!tokens || count == 0) return LittlefsCommand::None;
    const bool check = keywordEqual(tokenText(tokens[0].text), universal::kCheck);
    const bool format = keywordEqual(tokenText(tokens[0].text), universal::kFormat);
    if (!check && !format) return LittlefsCommand::None;
    if (tokens[0].quoted || count < 2 || tokens[1].quoted ||
        !keywordEqual(tokenText(tokens[1].text), universal::kLittlefs))
        return LittlefsCommand::Invalid;
    if (check) return count == 2 ? LittlefsCommand::Check : LittlefsCommand::Invalid;
    return count == 3 && !tokens[2].quoted &&
        keywordEqual(tokenText(tokens[2].text), universal::kConfirm)
        ? LittlefsCommand::Format : LittlefsCommand::Invalid;
}
// Input must have length + 1 writable bytes. Text is preserved byte-for-byte;
// only delimiters become NUL. No escaping: backslashes remain literal data.
// On error count is zero; callers must not dispatch partial tokens.
inline ParseError tokenize(char *line, size_t length, Token *tokens,
                           size_t capacity, size_t &count) {
    count = 0;
    if (!line || !tokens) return ParseError::NullInput;
    if (length > MAX_COMMAND) return ParseError::TooLong;
    for (size_t i = 0; i < length; ++i) {
        const unsigned char c = static_cast<unsigned char>(line[i]);
        if ((c < 32 && !whitespace(line[i])) || c == 127)
            return ParseError::InvalidCharacter;
    }
    line[length] = 0;
    size_t n = 0;
    char *p = line;
    while (*p) {
        while (whitespace(*p)) ++p;
        if (!*p) break;
        if (n >= capacity || n >= MAX_TOKENS) return ParseError::TooManyTokens;
        const bool quoted = *p == '"';
        if (quoted) ++p;
        tokens[n].text = p;
        tokens[n].quoted = quoted;
        if (quoted) {
            while (*p && *p != '"') ++p;
            if (*p != '"') return ParseError::InvalidQuote;
            *p++ = 0;
            if (*p && !whitespace(*p)) return ParseError::InvalidQuote;
        } else {
            while (*p && !whitespace(*p)) {
                if (*p == '"') return ParseError::InvalidQuote;
                ++p;
            }
            if (*p) *p++ = 0;
        }
        ++n;
    }
    count = n;
    return ParseError::None;
}
}} // namespace sx::commands
