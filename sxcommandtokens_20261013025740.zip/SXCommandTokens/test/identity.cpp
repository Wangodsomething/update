#include <SXCommandTokens.h>
#include <cassert>
#include <cstdio>
#include <cstdarg>
#include <string>
using namespace sx::commands;
struct StringToken { std::string text; bool quoted = false; };
struct Print {
    std::string text;
    void println(const char *s) { text += s; text += "\n"; }
    void printf(const char *fmt, ...) {
        char buffer[256]; va_list args; va_start(args, fmt);
        vsnprintf(buffer, sizeof(buffer), fmt, args); va_end(args); text += buffer;
    }
};
constexpr int ESP_OK = 0, ESP_MAC_WIFI_STA = 1, ESP_MAC_BT = 2;
int reads = 0, last_type = 0, mac_result = ESP_OK;
int esp_read_mac(uint8_t *mac, int type) {
    ++reads; last_type = type;
    const uint8_t wifi[] = {0x10,0xAB,0x02,0x00,0xFE,0x01};
    memcpy(mac, wifi, 6); if (type == ESP_MAC_BT) mac[5] = 3;
    return mac_result;
}
void get_imei_string(char *out, size_t size) { snprintf(out, size, "00010AB0200FE01"); }
char _imei[17] = "123456789012345";
bool lock_ok = true; unsigned timeout = 0;
struct NetworkMutexGuard {
    NetworkMutexGuard(int, unsigned ms) { timeout = ms; }
    explicit operator bool() const { return lock_ok; }
};
struct Network {
    int _networkMutex = 1;
    static bool valid_imei(const char*);
    bool copy_imei(char*, size_t);
} network;
#include "identity_under_test.h"
void query(const char *line, IdentityQuery expected) {
    char buffer[256]; snprintf(buffer,sizeof(buffer),"%s",line);
    Token tokens[MAX_TOKENS]; size_t count;
    assert(tokenize(buffer, strlen(buffer), tokens, MAX_TOKENS, count) == ParseError::None);
    assert(identityQuery(tokens, count) == expected);
    StringToken strings[MAX_TOKENS];
    for (size_t i=0;i<count;++i) { strings[i].text=tokens[i].text; strings[i].quoted=tokens[i].quoted; }
    assert(identityQuery(strings, count) == expected);
}
int main() {
    query("get imei",IdentityQuery::Imei);
    query("GeT WiFi MaC",IdentityQuery::WifiMac);
    query("GET BLE MAC",IdentityQuery::BleMac);
    query("get wifi",IdentityQuery::None);
    query("get id",IdentityQuery::None);
    query("set wifi mac",IdentityQuery::None);
    query("get",IdentityQuery::None);
    query("get imei extra",IdentityQuery::Invalid);
    query("get ble",IdentityQuery::Invalid);
    query("get wifi mac extra",IdentityQuery::Invalid);
    query("get ble address",IdentityQuery::Invalid);
    query("get \"imei\"",IdentityQuery::Invalid);
    query("get wifi \"mac\"",IdentityQuery::Invalid);
    query("get \"ble\" mac",IdentityQuery::Invalid);
    for (auto handler : {icebox_device::print_identity_query, h1_device::print_identity_query}) {
        Print out; reads=0;
        assert(handler(IdentityQuery::WifiMac,out));
        assert(out.text == "WiFi MAC: 10:AB:02:00:FE:01\n" && reads == 1 && last_type == ESP_MAC_WIFI_STA);
        out.text.clear(); assert(handler(IdentityQuery::BleMac,out));
        assert(out.text == "BLE MAC: 10:AB:02:00:FE:03\n" && last_type == ESP_MAC_BT);
        out.text.clear(); mac_result=-1;
        assert(!handler(IdentityQuery::WifiMac,out));
        assert(out.text == "ERR: MAC address unavailable\n"); mac_result=ESP_OK;
        out.text.clear(); const int before=reads;
        assert(!handler(IdentityQuery::Invalid,out)); assert(reads == before);
    }
    Print out;
    assert(h1_device::print_identity_query(IdentityQuery::Imei,out));
    assert(out.text == "IMEI: 123456789012345\n" && timeout == 100);
    out.text.clear(); lock_ok=false;
    assert(!h1_device::print_identity_query(IdentityQuery::Imei,out));
    assert(out.text == "ERR: IMEI unavailable or network busy\n");
    lock_ok=true; _imei[0]=0; out.text.clear();
    assert(!h1_device::print_identity_query(IdentityQuery::Imei,out));
    char small[2] = {}; assert(!network.copy_imei(small,sizeof(small)));
    assert(!network.copy_imei(nullptr,17));
    out.text.clear(); assert(icebox_device::print_identity_query(IdentityQuery::Imei,out));
    assert(out.text == "IMEI: 00010AB0200FE01\n");
    puts("PASS: identity grammar, both production handlers, IMEI snapshot and MAC error paths");
}
