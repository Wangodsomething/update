// Common Arduino macros must not collide with library token identifiers.
#define HIGH 1
#define LOW 0
#define DISPLAY 1
#include <SXCommandTokens.h>
#include <cassert>
#include <cstdio>
#include <string>
using namespace sx::commands;
using String = std::string;
#include "adapters_under_test.h"

void check(const std::string &input, bool valid, size_t expected = 0) {
    char buffer[512] = {};
    assert(input.size() < sizeof(buffer));
    memcpy(buffer, input.data(), input.size());
    Token tokens[MAX_TOKENS];
    size_t count = 99;
    const auto result = tokenize(buffer, input.size(), tokens, MAX_TOKENS, count);
    assert((result == ParseError::None) == valid);
    assert(count == (valid ? expected : 0));
    // Compile and call the actual firmware adapters, not duplicate parsers.
    UsbToken ice[MAX_TOKENS];
    uint8_t ice_count = 99;
    assert(tokenize_usb_command(input, ice, ice_count) == valid);
    assert(ice_count == count);
    char hline[512] = {};
    memcpy(hline, input.data(), input.size());
    Token h1[MAX_TOKENS];
    int hcount = 99;
    // H1's length-taking command entry rejects embedded NUL before splitArgs.
    if (input.find('\0') == std::string::npos) {
        assert(splitArgs(hline, h1, MAX_TOKENS, hcount) == valid);
        assert(size_t(hcount) == count);
    }
    if (valid) for (size_t i = 0; i < count; ++i) {
        assert(ice[i].text == tokens[i].text);
        assert(ice[i].quoted == tokens[i].quoted);
        assert(strcmp(h1[i].text, tokens[i].text) == 0);
        assert(h1[i].quoted == tokens[i].quoted);
    }
}
int main() {
    check("", true, 0);
    check(" \t\r\n", true, 0);
    check("GET\tversion\r\n", true, 2);
    check("set wifi \"Case Sensitive SSID\" \"P@ss WORD\"", true, 4);
    check("set mqtt \"Host\" 1883 \"\" \"\"", true, 6);
    check("print /CaseSensitive/Log.txt", true, 2);
    check("update https://Host/Build.bin?Key=AbC SHA256", true, 3);
    check("set wifi \"Back\\slash\" \"123\"", true, 4);
    check("set mode mobile", true, 3);
    check("write modbus 1 3 0 0 0 2 crc", true, 9);
    check("\"unterminated", false);
    check("get \"wifi\"tail", false);
    check("get wi\"fi", false);
    check("a b c d e f g h i j k l", true, 12);
    check("a b c d e f g h i j k l m", false);
    check(std::string(255, 'x'), true, 1);
    check(std::string(256, 'x'), false);
    check(std::string("restart\0get config", 18), false);
    check(std::string("get \x01wifi"), false);
    check(std::string("get \x7fwifi"), false);
    char line[] = "set wifi";
    Token tokens[MAX_TOKENS]; size_t count = 123;
    assert(tokenize(line, strlen(line), tokens, 1, count) == ParseError::TooManyTokens && count == 0);
    assert(tokenize(nullptr, 0, tokens, MAX_TOKENS, count) == ParseError::NullInput);
    assert(keywordEqual("ReStArT", universal::kRestart));
    assert(!keywordEqual("restarts", universal::kRestart));
    assert(!keywordEqual(nullptr, universal::kGet));
    assert(keywordEqual("mobile", icebox::kMobile));
    assert(keywordEqual("MODBUS", h1::kModbus));
    char payload[] = "set wifi \"Case SSID\" \"P@ss\\word\"";
    assert(tokenize(payload, strlen(payload), tokens, MAX_TOKENS, count) == ParseError::None);
    assert(count == 4 && tokens[2].quoted && tokens[3].quoted);
    assert(strcmp(tokens[2].text, "Case SSID") == 0);
    assert(strcmp(tokens[3].text, "P@ss\\word") == 0);
    puts("PASS: shared command parser and actual Icebox/H1 adapters");
}
