"""Host tests: shared parser plus actual adjacent Icebox and H1 adapters."""
from pathlib import Path
import os, shutil, subprocess
ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / ".build"
BUILD.mkdir(exist_ok=True)
def section(path, start, end):
    text = path.read_text()
    return text[text.index(start):text.index(end, text.index(start))]
adapters = section(ROOT.parent / "SX-P2/src/network.cpp", "struct UsbToken", "#define Serial command_output()")
adapters += section(ROOT.parent / "SX-H1-DUAL-1/src/helpers.cpp", "bool splitArgs", "bool parseUInt8Strict")
(BUILD / "adapters_under_test.h").write_text(adapters)
def function(path, signature):
    text = path.read_text()
    start = text.index(signature)
    opening = text.index("{", start)
    depth, end = 1, opening + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]
h1 = ROOT.parent / "SX-H1-DUAL-1/src/network.cpp"
identity = function(h1, "bool Network::valid_imei(") + "\n" + function(h1, "bool Network::copy_imei(")
for name, path in (("icebox_device", ROOT.parent / "SX-P2/src/network.cpp"),
                   ("h1_device", ROOT.parent / "SX-H1-DUAL-1/src/helpers.cpp")):
    identity += "\nnamespace " + name + " {\n" + function(path, "bool print_identity_query(") + "\n}\n"
(BUILD / "identity_under_test.h").write_text(identity)
for test in ("parser", "identity"):
    source = ROOT / ("test/" + test + ".cpp")
    if os.name == "nt":
        setups = sorted(Path("C:/Program Files (x86)/Microsoft Visual Studio").glob("*/BuildTools/VC/Auxiliary/Build/vcvars64.bat"))
        if not setups: raise SystemExit("MSVC Build Tools not found")
        exe = BUILD / "commands.exe"
        script = BUILD / "build.cmd"
        script.write_text(f'@echo off\ncall "{setups[-1]}" >nul\ncl /nologo /std:c++14 /EHsc /W4 /WX /I"{ROOT / "src"}" /I"{BUILD}" "{source}" /Fo"{BUILD / "commands.obj"}" /Fe"{exe}"\nexit /b %errorlevel%\n')
        subprocess.run(["cmd", "/d", "/c", str(script)], cwd=BUILD, check=True)
    else:
        exe = BUILD / "commands"
        cc = shutil.which("g++") or shutil.which("clang++")
        if not cc: raise SystemExit("C++ compiler not found")
        subprocess.run([cc, "-std=c++11", "-Wall", "-Wextra", "-Werror", "-I", str(ROOT / "src"), "-I", str(BUILD), str(source), "-o", str(exe)], check=True)
    subprocess.run([str(exe)], check=True)
