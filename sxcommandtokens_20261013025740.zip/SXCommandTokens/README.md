# SXCommandTokens

A single header-only C++11 library used by the SX-P2/SX-C1 (Icebox) logger and
SX-H1-DUAL-1. It supplies text token constants and a bounded, allocation-free
parser. Tokens are human-readable command words, not numeric protocol opcodes.

## Layout and installation

Keep the library alongside both firmware repositories:

```text
Projects/
  SXCommandTokens/src/SXCommandTokens.h
  SX-P2/platformio.ini
  SX-H1-DUAL-1/platformio.ini
```

Both projects use `SXCommandTokens=symlink://../SXCommandTokens` in `lib_deps`.
The Icebox compatibility project uses `symlink://../../SXCommandTokens`.
All targets compile the same header; there are no vendored copies to keep in sync.
For a standalone checkout, copy/install this library too and adjust the dependency
path as needed. Publishing/version-pinning a Git package is a future distribution
step; this change does not create a remote repository.

## Vocabulary

| Namespace | Purpose | Examples |
| --- | --- | --- |
| `sx::commands::universal` | Shared verbs, targets and reusable values | `kGet`, `kSet`, `kRestart`, `kVersion`, `kWifi`, `kMqtt`, `kOff` |
| `sx::commands::icebox` | Logger-specific operations and values | `kMode`, `kStationary`, `kMobile`, `kTemp`, `kHumi`, `kPower`, `kTimezone` |
| `sx::commands::h1` | Hub-specific operations and values | `kModbus`, `kModem`, `kApn`, `kSim`, `kBreaker`, `kAlert`, `kBuzzer` |

The common commands implemented by both devices include:

```text
help
get version
get imei
get wifi mac
get ble mac
get config
get data
get queue
get wifi
get mqtt
get time
get espnow
scan wifi
restart
update <https-url> <sha256>
print </absolute-path>
check littlefs
format littlefs CONFIRM
set wifi ...
set mqtt ...
set time ...
```

A token constant does not authorize a command or advertise device support.
In particular, `id` and `conf` remain logger features; reusable vocabulary does
not add H1 handlers for them. Argument schemas and responses stay in each
firmware: for example Wi-Fi slots, MQTT parameters, time setting, ESP-NOW
configuration and file aliases retain their existing device-specific behavior.
Use each firmware's usage messages/documentation for the exact syntax.

## Parsing contract

- At most 255 bytes and 12 tokens. No partial dispatch on a parse failure.
- Space, tab, CR and LF separate tokens. Double quotes enclose a value containing
  whitespace, including an empty string. A closing quote must be followed by
  whitespace or end of input. Quotes inside an unquoted token are invalid.
- Backslashes are literal; there is no escape syntax. NUL and other non-whitespace
  control bytes, including DEL, are rejected by the length-aware parser.
- `tokenize` takes a mutable buffer with `length + 1` writable bytes. It replaces
  delimiters with NUL and returns token views; the caller owns their lifetime.
- The tokenizer preserves case and marks quoted values. `keywordEqual` is ASCII
  case-insensitive. Callers must check quote/argument requirements before action.
- Icebox adapts token views into existing `String` handlers. H1 uses views directly.
  Both reject quoted command verbs. H1 now accepts mixed-case command keywords,
  like Icebox; URLs, paths and quoted credentials retain their bytes.
- Existing authentication, origin restrictions, deferred restart/reply delivery,
  storage validation and device actions remain in firmware. This is not an
  authorization or command-dispatch library.

Example:

```cpp
#include <SXCommandTokens.h>
char line[] = "get version";
sx::commands::Token tokens[sx::commands::MAX_TOKENS];
size_t count = 0;
const auto error = sx::commands::tokenize(
    line, sizeof(line) - 1, tokens, sx::commands::MAX_TOKENS, count);
if (error == sx::commands::ParseError::None && count == 2 &&
    !tokens[0].quoted && !tokens[1].quoted &&
    sx::commands::keywordEqual(tokens[0].text, sx::commands::universal::kGet) &&
    sx::commands::keywordEqual(tokens[1].text, sx::commands::universal::kVersion)) {
    // Invoke this device's version handler.
}
```

## Validation

`python scripts/test_commands.py` compiles the library and the actual tokenization
adapters from the adjacent firmware projects with MSVC or GCC/Clang. Tests cover
quoted/empty values, payload case, literal backslashes, whitespace, boundaries,
excess tokens, malformed quotes, control characters, embedded NUL and mixed-case
keyword comparison. Firmware builds cover `sx-p2`, `sx-c1`, `icebox-1` and H1
`esp32dev`. Existing logger power/storage/transport regressions remain applicable.
No firmware upload is part of these commands.

## Separate identity queries

Both firmware projects support these exact, case-insensitive commands:

| Command | Reply | Meaning |
| --- | --- | --- |
| `get imei` | `IMEI: <identifier>` | H1: verified/cached 15-digit modem IMEI. Icebox: existing 15-character MAC-derived server identifier (no cellular modem IMEI). |
| `get wifi mac` | `WiFi MAC: AA:BB:CC:DD:EE:FF` | This device's Wi-Fi station MAC, not an AP/BSSID or peer MAC. |
| `get ble mac` | `BLE MAC: AA:BB:CC:DD:EE:FF` | This device's public Bluetooth/BLE MAC, not a peer or temporary private advertising address. |

MAC queries use `esp_read_mac` and work without starting Wi-Fi or Bluetooth.
H1 IMEI queries take a bounded, recursive network lock and return
`ERR: IMEI unavailable or network busy` if the snapshot cannot be obtained;
they do not issue modem AT commands. Malformed identity queries return a usage
error. Icebox's existing `get id` alias and both devices' `get wifi` configuration
queries keep their previous behavior. The shared `identityQuery` recognizer
accepts both firmware token representations and validates arity and quoting.

## LittleFS maintenance

`kCheck`, `kFormat`, `kLittlefs`, and `kConfirm` belong to `universal`.
Both devices use `littlefsCommand` to validate unquoted, case-insensitive
keywords and exact argument counts. Formatting requires the explicit `CONFIRM`
argument and erases all files, including configuration and buffered records.
File printing continues to use `universal::kPrint`; aliases stay device-specific.

H1 checks storage under its storage mutex without unmounting a live filesystem.
Confirmed H1 formatting is deferred until a software reboot, before application
tasks start. The reply reports scheduling; boot serial output reports the actual
format/default-restoration result. Failed storage startup leaves a limited serial
recovery console available. No device is formatted by building this library.
